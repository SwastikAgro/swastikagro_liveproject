package com.jsp.Springboot_liveproject1.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.jsp.Springboot_liveproject1.dao.PostDao;
import com.jsp.Springboot_liveproject1.dao.UserDao;
import com.jsp.Springboot_liveproject1.entity.Image;
import com.jsp.Springboot_liveproject1.entity.Post;
import com.jsp.Springboot_liveproject1.entity.User;
import com.jsp.Springboot_liveproject1.util.ResponseStructure;
@Service
public class PostService {
	@Autowired
	private PostDao dao;
	@Autowired
	private UserDao udao;
	public ResponseEntity<ResponseStructure<Post>> savePost(int id, String location, String caption,
			MultipartFile file) throws IOException {
		User userDb = udao.fetchUser(id);
		if(userDb!=null) {
			Image image=new Image();
			image.setPic(file.getBytes());
		}
		return null;
	}

}
