package com.jsp.Springboot_liveproject1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootLiveproject1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootLiveproject1Application.class, args);
	}
}
