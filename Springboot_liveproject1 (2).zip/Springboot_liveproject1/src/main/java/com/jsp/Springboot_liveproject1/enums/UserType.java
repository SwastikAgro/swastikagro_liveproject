package com.jsp.Springboot_liveproject1.enums;

public enum UserType {
	farmer

}
