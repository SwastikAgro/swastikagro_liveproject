package com.jsp.Springboot_liveproject1.dao;

public class RentalDao {

}
