package com.jsp.Springboot_liveproject1.entity;

public class Image {

}
